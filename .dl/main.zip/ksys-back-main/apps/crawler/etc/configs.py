NATL_TOP_URL = "https://www.kaigokensaku.mhlw.go.jp/"
DEFAULT_SELENIUM_WAIT_TIME = 3
DATE_FORMAT = "%Y-%m-%d"

SEARCH_PREFS = ["北海道"]

DATABASE_SCHEME = "sqlite:///"
DATABASE_PATH = "../db/out/kk_jigyosyo2.db"
DATABASE_DST = DATABASE_SCHEME + DATABASE_PATH
TABLE_NAME = "list_table"
